from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Student
from app.schemas import StudentUpdate, StudentResponse

router = APIRouter(prefix="/students", tags=["Students"])


@router.put("/{student_id}", response_model=StudentResponse)
def update_student(
    student_id: int, payload: StudentUpdate, db: Session = Depends(get_db)
):
    student = db.query(Student).filter(Student.id == student_id).first()
    if student is None:
        raise HTTPException(status_code=404, detail="Student not found.")

    update_data = payload.model_dump(exclude_unset=True)
    if "email" in update_data and update_data["email"] is not None:
        duplicate = (
            db.query(Student)
            .filter(Student.email == update_data["email"], Student.id != student_id)
            .first()
        )
        if duplicate:
            raise HTTPException(
                status_code=409,
                detail="Another student is already using this email.",
            )

    for field, value in update_data.items():
        setattr(student, field, value)

    db.commit()
    db.refresh(student)
    return student
