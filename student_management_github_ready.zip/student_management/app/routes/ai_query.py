from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Student

router = APIRouter(prefix="/students", tags=["AI Extension"])


class AIQuery(BaseModel):
    question: str = Field(min_length=1, max_length=1000)


@router.post("/query-ai")
def query_local_ai(payload: AIQuery, db: Session = Depends(get_db)):
    # Import lazily so the main CRUD API works even when Ollama is not installed
    # or the local model has not been downloaded.
    try:
        from langchain_ollama import ChatOllama

        students = db.query(Student).order_by(Student.id).all()
        db_records = "\n".join(
            f"ID: {s.id}, Name: {s.student_name}, DOB: {s.dob}, "
            f"Email: {s.email}, Course: {s.course}, Enrolled: {s.enrollment_date}"
            for s in students
        ) or "No student records are currently stored."

        system_prompt = (
            "You are an assistant for a student management database. "
            "Answer only from the records provided. If the records do not "
            "contain the answer, say so. Be concise and do not invent details."
        )
        prompt = (
            f"{system_prompt}\n\nStudent records:\n{db_records}"
            f"\n\nQuestion: {payload.question}"
        )
        response = ChatOllama(model="llama3.2").invoke(prompt)
        return {
            "status": "success",
            "question": payload.question,
            "response": response.content,
        }
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=(
                "The local AI service is unavailable. Make sure Ollama is running "
                "and the llama3.2 model is installed."
            ),
        ) from exc
