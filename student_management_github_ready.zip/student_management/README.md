# Student Management API

A small REST API built with FastAPI and SQLAlchemy for storing and managing student records. It was prepared as an EWB internship project and includes an optional local AI query endpoint.

## Features

- Add, view, update and delete student records
- List all students or filter by course
- Validate email addresses and prevent duplicate emails
- Store records in a local SQLite database
- Explore and test endpoints through the built-in API documentation
- Optional local AI questions using Ollama and the `llama3.2` model

## Built with

- Python
- FastAPI
- SQLAlchemy
- Pydantic
- SQLite
- Ollama (optional AI feature)

## Project structure

```text
student_management/
├── app/
│   ├── routes/
│   │   ├── create_student.py
│   │   ├── get_student.py
│   │   ├── update_student.py
│   │   ├── delete_student.py
│   │   └── ai_query.py
│   ├── __init__.py
│   ├── config.py
│   ├── database.py
│   ├── models.py
│   └── schemas.py
├── .env.example
├── .gitignore
├── main.py
├── requirements.txt
└── README.md
```

## Getting started

You need Python 3.10 or newer.

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Create a virtual environment:

   ```bash
   python -m venv .venv
   ```

4. Activate it.

   **Windows PowerShell**
   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   **macOS / Linux**
   ```bash
   source .venv/bin/activate
   ```

5. Install the packages:

   ```bash
   pip install -r requirements.txt
   ```

6. Copy `.env.example` to `.env`. The default SQLite setting works for a local run.

7. Start the API:

   ```bash
   python -m uvicorn main:app --reload
   ```

8. Open `http://127.0.0.1:8000/docs` in your browser to test the endpoints.

The SQLite database file (`students.db`) is created automatically when the app starts.

## Main endpoints

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/` | Basic welcome message |
| GET | `/health` | Health check |
| POST | `/students/` | Add a student |
| GET | `/students/` | List students |
| GET | `/students/?course=BSc%20IT` | Filter students by course |
| GET | `/students/{student_id}` | Get one student |
| PUT | `/students/{student_id}` | Update a student |
| DELETE | `/students/{student_id}` | Delete a student |
| POST | `/students/query-ai` | Ask the optional local AI a question |

For the AI endpoint, send JSON such as:

```json
{
  "question": "How many students are enrolled in BSc IT?"
}
```

The optional AI feature requires Ollama to be installed and running, with the `llama3.2` model available locally. The CRUD endpoints do not require Ollama.

## Notes

- This is a learning and internship project, not a production deployment.
- Student dates are stored as strings in this version.
- Keep `.env` and the local database out of public commits.
- Check the API responses in `/docs` before using it with real student data.
