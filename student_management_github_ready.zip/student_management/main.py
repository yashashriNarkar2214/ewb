from fastapi import FastAPI

from app.database import Base, engine
from app.routes import (
    ai_query,
    create_student,
    delete_student,
    get_student,
    update_student,
)

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="EWB Student Management API",
    description=(
        "A student records API with CRUD operations, course filtering, "
        "and an optional local AI query endpoint."
    ),
    version="1.0.0",
)

app.include_router(create_student.router)
app.include_router(get_student.router)
app.include_router(update_student.router)
app.include_router(delete_student.router)
app.include_router(ai_query.router)


@app.get("/", tags=["General"])
def read_root():
    return {
        "message": "Welcome to the EWB Student Management API.",
        "docs": "/docs",
        "health": "ok",
    }


@app.get("/health", tags=["General"])
def health_check():
    return {"status": "ok"}
